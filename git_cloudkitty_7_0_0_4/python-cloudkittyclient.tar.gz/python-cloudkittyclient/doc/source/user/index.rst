========
Usage
========

To use python-cloudkittyclient in a project::

    import cloudkittyclient
