========================================================
Welcome to python-cloudkittyclient's documentation!
========================================================

This is a client library for CloudKitty built on the CloudKitty API. It
provides a Python API (the ``cloudkittyclient`` module).

Contents:

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   cli/index
   user/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

