===========
policy.yaml
===========

Use the ``policy.yaml`` file to define additional access controls that apply to
the Rating service:

.. literalinclude:: ../../_static/policy.yaml.sample
