#############
API Reference
#############

.. toctree::
   :glob:

   webapi/root
   webapi/v1
   webapi/rating/*
